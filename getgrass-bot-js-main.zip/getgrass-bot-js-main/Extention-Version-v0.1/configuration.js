// configuration
const config = {
    "User-Agent": "xxxxxxx", // Replace with Your useragent
    "Origin": "chrome-extension://xxxxxxx", // Replace with Your chrome-extension ID HERE
    extension_id: "xxxxxxx", // Replace with Your chrome-extension ID HERE
    userId: 'xxxxx-xxx-xxxxx-xxxx-xxxxxxxx',  // Replace with Your User ID HERE
    proxyFile: 'proxy.txt' // your Path to Proxy.txt file
    // format proxies is => socks5://username:pass@ip:port
};

module.exports = config;